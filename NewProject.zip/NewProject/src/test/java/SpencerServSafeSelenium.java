import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SpencerServSafeSelenium {
    Date date = new Date();
    String str = new SimpleDateFormat("yyyyMMddHHmm").format(date);
    String value = "ypatel822+"+str+"@gmail.com";

    @Test
    public void FirstChallenge() {

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.servsafe.com/");

        WebElement loginText = driver.findElement(By.xpath("//div[@class='masthead-top-nav-right']/child::a"));
        loginText.click();

        WebElement createAccountButton = driver.findElement(By.xpath("//a[@id='createAccount-Btn']"));
        createAccountButton.click();

        WebElement enterEmailAddress = driver.findElement(By.xpath("//input[@id='emailToCheck']"));
        enterEmailAddress.sendKeys(value);

        WebElement clickSubmitButton = driver.findElement(By.xpath("//a[@id='doCheckUniquenessButton']"));
        clickSubmitButton.click();

        WebElement enterFirstName = driver.findElement(By.xpath("//div[@id='container-givenName']/child::input"));
        enterFirstName.sendKeys("Yatin");

        WebElement enterLastName = driver.findElement(By.xpath("//div[@id='container-sn']/child::input"));
        enterLastName.sendKeys("Patel");

        Select emailType = new Select(driver.findElement(By.xpath("//select[@id='emailType']")));
        emailType.selectByValue("Personal");

        Select addressType = new Select(driver.findElement(By.xpath("//select[@id='addressType']")));
        addressType.selectByValue("Home");

        WebElement enterAddress1 = driver.findElement(By.xpath("//input[@id='address1']"));
        enterAddress1.sendKeys("871 Tallgrass Dr");

        WebElement enterCity = driver.findElement(By.xpath("//input[@id='city']"));
        enterCity.sendKeys("Bartlett");

        Select country = new Select(driver.findElement(By.xpath("//select[@id='country']")));
        country.selectByValue("US");

        Select state = new Select(driver.findElement(By.xpath("//select[@id='state']")));
        state.selectByValue("IL");

        WebElement enterZipcode = driver.findElement(By.xpath("//input[@id='zipCode']"));
        enterZipcode.sendKeys("60103");

        Select mobileCountry = new Select(driver.findElement(By.xpath("//select[@id='mobileCountry']")));
        mobileCountry.selectByValue("+1 (United States)");

        WebElement enterMobileNumber = driver.findElement(By.xpath("//input[@id='phoneNumber']"));
        enterMobileNumber.sendKeys("2477894563");

        Select jobRole = new Select(driver.findElement(By.xpath("//select[@id='jobRole']")));
        jobRole.selectByValue("Academic Student");

        WebElement enterPassword = driver.findElement(By.xpath("//input[@id='password']"));
        enterPassword.sendKeys("Tester1234!");

        WebElement enterConfirmPassword = driver.findElement(By.xpath("//input[@id='confirmPassword']"));
        enterConfirmPassword.sendKeys("Tester1234!");

        WebElement clickCreateAccountButton = driver.findElement(By.xpath("//a[@id='submitButton']"));
        clickCreateAccountButton.click();

        WebElement enterPasscode = driver.findElement(By.xpath("//input[@id='Passcode']"));
        enterPasscode.sendKeys("138674");

        WebElement clickContinueButton = driver.findElement(By.xpath("//input[@id='submitBtn']"));
        clickContinueButton.click();

    }

    @Test
    public void SecondChallenge() {

    }

}
